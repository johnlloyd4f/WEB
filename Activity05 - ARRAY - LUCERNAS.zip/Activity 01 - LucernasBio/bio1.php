<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="bio1.css"> 
  <title>John Lloyd Lucernas</title>
  <img src="images/pic1.jpg.jpg" alt="Gwapo">
</head>
<body>
  
</body>
</html>
<div  class="pic3">
<img src="images/pic3.jpg" alt="Gwapooo">
</div>

<div class="header-resp">
  <h1><?php include 'array/data.php'; echo $info['name'] ?></h1>
  <h2>"<?php include 'array/data.php'; echo $info['line'] ?>"</h2>
  <h3><?php include 'array/data.php'; echo $info['year'] ?></h3>
</div>
<header>
  <div class="header-lockup">
    <h1><?php include 'array/data.php'; echo $info['name'] ?></h1>
    <h2>"<?php include 'array/data.php'; echo $info['line'] ?>"</h2>
    <h3><?php include 'array/data.php'; echo $info['year'] ?></h3>
  </div>
<!--  END OF HEADER LOCKUP  -->
</header>
<!-- END OF HEADER -->

<section>
  <div class="content-lockup">
    <h2>Biography</h2>
    <p>Born in Cebu City, Cebu on September 18 and was raised in Lower Hermag,  Pagsabungan Mandaue City. A Student that a dream to become a Computer Programmer. </p>
    <p>I began interesting at computer at the age of 13, Graduated in Basak Elementary School as a ALS Student on 2019 and Apply for a job on September 19, 2020. </p>
    <p>Resign on a job January 06, 2021, to pursue my dream as a Computer Engineering in Cite Technical Institute at January 05, 2021, to experience also as a College Students.</p>
    <div class="timeline">
      <h2>Timeline</h2>
      <ul>
        <li><?php include 'array/data.php'; echo $bio['born'] ?>- Born in Cebu City, Cebu on September 18
        </li>
        <li><?php include 'array/data.php'; echo $bio['b2'] ?>- Went to Basak Elementary School to study as a Elementary level. </li>
        <li><?php include 'array/data.php'; echo $bio['b3'] ?>- Graduated as a Elementary Level on April 28 </li>
        <li><?php include 'array/data.php'; echo $bio['b4'] ?> - Becomes a Junior HighSchool student.</li>
        <li><?php include 'array/data.php'; echo $bio['b5'] ?>- Graduated in Als Student in Basak Elementary School as a College Level.</li>
        <li><?php include 'array/data.php'; echo $bio['b6'] ?> - Experienced as a Service crew in Jollibee Fast food chain</li>
        <li>2021- On january 05, 2021 Apply a scholarship in Cite Technical Institute to pursue my dreams, and Resign my job at January 06, 2021. </li>
        <li> - Son John Lloyd Lucernas is Born</li>
      </ul>
    </div>
    <!--   END OF TIMELINE   -->
    
    <div class="filmography">
      <h2>Notable Films</h2>
      <ul>
</section>