<?php

$info = array ("name" => "John Lloyd Lucernas",
                "line" => "As you think, so shall you become",
                "year" => "2000 - 2022");

 
$bio = array ("born" => "2000",
               "b2" => "2006",
               "b3" => "2014" ,
               "b4" => "2014-15",
               "b5" => "2019", 
               "b6" => "2020",
               "b7" => "2020")   ;            

?>